local a = true

local DrawTextFormat = function(x,y,text,entry)
    AddTextEntry(entry, text)
    SetTextFont(0) 
    SetTextProportional(0)
    SetTextScale(0.42, 0.42)
    SetTextDropShadow(0,0,0,0,255)
    SetTextColour(255, 255, 255, 255)
    BeginTextCommandDisplayText(entry)
    DrawText(x, y)
end

Citizen.CreateThread(function() 
  
    while a == true do 
        local coords = GetEntityCoords(PlayerPedId())
        DrawTextFormat(0.35, 0.10, "X: " .. tostring(coords[1]), "x-coord")
        DrawTextFormat(0.35, 0.15, "Y: " .. tostring(coords[2]), "y-coord")
        DrawTextFormat(0.35, 0.20, "Z: " .. tostring(coords[3]), "z-coord")
        Citizen.Wait(1)
    end
end)

RegisterCommand('closecoords', function() 
    a = false
end)

